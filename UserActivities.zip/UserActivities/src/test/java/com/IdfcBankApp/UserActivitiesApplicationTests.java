package com.IdfcBankApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserActivitiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
