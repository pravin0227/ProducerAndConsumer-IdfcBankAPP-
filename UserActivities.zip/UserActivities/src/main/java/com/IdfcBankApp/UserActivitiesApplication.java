package com.IdfcBankApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserActivitiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserActivitiesApplication.class, args);
	}

}
