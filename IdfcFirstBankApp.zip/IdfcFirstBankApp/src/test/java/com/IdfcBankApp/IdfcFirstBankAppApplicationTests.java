package com.IdfcBankApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdfcFirstBankAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
